package Server;

/**
 * Created by SIMONE on 2017/03/01.
 */
public class Main {
    public static void main(String args[]){
        TwistServer twistServer = new TwistServer();
        twistServer.start();
    }
}
