package Client;

/**
 * Created by SIMONE on 11/03/2017.
 */
public class MyString {
    private String string;

    public MyString(){

    }

    public void setString(String string){
        this.string = string;
    }

    public String getString(){
        return this.string;
    }
}
