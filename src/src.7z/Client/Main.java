package Client;

/**
 * Created by SIMONE on 02/03/2017.
 */
public class Main {
    public static void main(String str[]){
        TwistClient client = new TwistClient();
        client.start();
    }
}
